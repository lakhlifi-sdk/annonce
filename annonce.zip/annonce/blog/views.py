from datetime import datetime
from django.shortcuts import render
import requests
from bs4 import BeautifulSoup
from blog import models
from blog.models import ContactForm
from blog.forms import UserInf


from django.conf.urls.static import static
def index(request,domain='Informatique',city='Rabat',key='dev',num='t590'):
	#print(key)
	URL1 = 'https://ma.indeed.com/emplois?q='+domain.lower()+'+'+key+'&l='+city+''
	#URL1 = 'https://ma.indeed.com/emplois?q=developpeur&l=Casablanca&advn=4401717887588522&vjk=84f8d93edcda6f86'
	page1 = requests.get(URL1)
	#URL2 = 'https://www.rekrute.com/offres.html?st=d&keywordNew=1&keyword='+city.capitalize()+'+'+domain.lower()+'&filterLogo=&filterLogo='
	URL2 = 'https://www.rekrute.com/offres.html?st=d&keywordNew=1&keyword='+key.capitalize()+'+'+domain.lower()+'&filterLogo=&filterLogo='
	page2 = requests.get(URL2)
	soup1 = BeautifulSoup(page1.content, "html.parser")
	soup2 = BeautifulSoup(page2.content, "html.parser")
	# --------print only elements which have as id='ResultsContainer'---------
	results1 = soup1.find(id="resultsCol")
	results2 = soup2.find(id="fortopscroll")

	job_elems1 = results1.find_all('div', class_='title')
	job_elems2 = results2.find_all('div', class_='col-sm-10 col-xs-12')
	#URL = 'https://www.marocannonces.com/maroc/offres-emploi-casablanca-b309-t563.html?kw=erp&f_3=Informatique'

	URL = 'https://www.marocannonces.com/maroc/offres-emploi-'+city.lower()+'-b309-'+num+'.html?kw='+key+'&f_3='+domain.capitalize()+''
	page = requests.get(URL)
	# --------------------------print html code-------------------------------
	soup = BeautifulSoup(page.content, "html.parser")
	# --------print only elements which have as id='ResultsContainer'---------
	results = soup.find(id='content')

	# in results we search a section elemnts which have as className='card-content'
	job_elems = results.find_all('li')

	# This code finds all <h2> elements where the contained string matches 'Python Developer' exactly
	python_jobs = results.find_all('div', class_="holder")
	#x = datetime.now()
	#fil = open(''+str((x.year))+str(x.strftime("%A"))+str(x.strftime("%B"))+'file'+'.html', "w")
	l=[]
	dic1={}
	dic2 = {}
	dic3 = {}

	for p_job3 in python_jobs:
	    link3 = p_job3.find('a')['href']
	    dic3[p_job3.text.strip()] = 'https://www.marocannonces.com/' + link3 + ''
	    #fil.write("<h1>from https://marocannace:<br> </h1>" + " " + "<a href=\"https://www.marocannonces.com/" + link3 + "\">link</a>" + p_job3.text.strip() + "<br><br>")

	for p_job in job_elems1:
	    link1 = p_job.find('a')['href']
	    dic1[p_job.text.strip()] = 'https://ma.indeed.com' + link1 + ''
	    #fil.write("from https://ma.indeed.com :" + " " + "<a href=\"https://ma.indeed.com" + link1 + "\"><h1>" + p_job.text.strip() + "</h1></a><br>")

	for p_job2 in job_elems2:
	    link2 = p_job2.find('a')['href']
	    l.append(link2)

	    dic2[p_job2.text.strip()] = 'https://www.rekrute.com/' + link2 + ''
	#fil.write("<h1>from https://www.rekrute.com:<br> :</h1>" + " " + "<a href=\"https://www.rekrute.com/" + link2 + "\">link</a>" + p_job2.text.strip() + "<br><br>")
	#fil.close()
	contactForm = ContactForm(request.POST or None)
	context = {'date': datetime.now(),'dic3': dic3,'dic1': dic1, 'dic2': dic2,
	           'ldic1':len(dic1),
	           'ldic2':len(dic2),
	           'ldic3':len(dic3),
	           'total':len(dic1)+len(dic2)+len(dic3),
	           'form':contactForm
	           }
	return render(request, 'offre/index.html', context)

	
def contact(request):
	form = ContactForm(request.POST or None)
	if request.method == 'POST':
		if form.is_valid():
			domain = form.cleaned_data['domain']
			city = form.cleaned_data['city']
			key = form.cleaned_data['key']
			domain = request.POST['domain']
			city = request.POST['city']
			key = request.POST['key']

			if city=="Rabat":
				num="t590"
			elif city=="Taza":
				num="t604"
			elif city=='Kénitra':
				num='t573'
			elif city == 'Khouribga':
				num = 't576'
			elif city=='Laayoune':
				num='t578'
			elif city=='Larache':
				num='t579'
			elif city=='Marrakech':
				num='t580'
			elif city=='Meknès':
				num='t582'
			elif city=='Berkane':
				num='t559'
			elif city=='Oujda':
				num='t589'
			elif city == 'Safi':
				num = 't591'
			elif city=='Dakhla':
				num='t565'
			elif city=='Errachidia':
				num='t793'
			elif city=='Agadir':
				num='t552'
			elif city=='Beni mellal':
				num='t557'
				city='beni-mellal'
			elif city=='Al hoceima':
				num='t553'
				city='al-hoceima'
			elif city == 'Casablanca':
				num = 't563'
			else:
				num='t590'



			return index(request,domain,city,key,num)
	else:
		return index(request)


def Register(request):

	userInf = UserInf(request.POST or None)
	context={'userInfo':userInf}
	userInfo=models.UserInfo()
	if request.method == 'POST':
		if userInf.is_valid():
			userInf
			# name = request.POST['name']
			# email = request.POST['email']
			# subject = request.POST['subject']
			# message=request.POST['message']


			name = form.cleaned_data['name']
			email = form.cleaned_data['email']
			subject = form.cleaned_data['subject']
			message = form.cleaned_data['message']


			userInfo.name = userInfo.cleaned_data['name']
			userInfo.email = userInfo.cleaned_data['email']
			userInfo.subject = userInfo.cleaned_data['subject']
			userInfo.message = userInfo.cleaned_data['message']
			

			print(name)
			print(email)
			print(subject)
			print(message)
			print(request.POST)
	return render(request, 'job/contact.html', context)

def date_actuelle(request):
    return render(request, 'blog/date.html', {'date': datetime.now()})
def index2(request):

    return render(request, 'job/index.html')

def about(request):
	return render(request, 'job/About.html')

def contact1(request):
	return render(request, 'job/contact.html')






from blog.forms import UserForm

def userf(request):

	form = UserForm(request.POST or None)

	if form.is_valid(): 

		userForm=models.UserMessage()
		# Ici nous pouvons traiter les données du formulaire
		# userForm.name = form.cleaned_data['name']
		# userForm.email = form.cleaned_data['email']
		# userForm.subject = form.cleaned_data['subject']
		# userForm.message = form.cleaned_data['message']

		userForm.name = form.cleaned_data['name']
		userForm.email = form.cleaned_data['email']
		userForm.subject = form.cleaned_data['subject']
		userForm.message = form.cleaned_data['message']
		userForm.save();

		return render(request, 'job/contact.html', locals())

	else:
		return render(request, 'job/contact.html')
