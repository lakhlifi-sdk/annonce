from django.contrib import admin
from blog.models import UserInfo,UserMessage

# Register your models here.
admin.site.register(UserInfo)
admin.site.register(UserMessage)