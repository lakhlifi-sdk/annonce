from django import forms

class UserInf(forms.Form):
    name = forms.CharField(label='Your name', max_length=100)#widget=forms.HiddenInput()
    email = forms.CharField(label='Your email', max_length=100)
    subject = forms.CharField(label='Your subject', max_length=100)
    message = forms.CharField(label='Your message', max_length=100)

from django import forms

class UserForm(forms.Form):
    name = forms.CharField(max_length=100)
    email = forms.EmailField(label="Votre adresse e-mail")
    subject = forms.CharField(max_length=100)
    message = forms.CharField(widget=forms.Textarea)
    