

# Create your models here.

from django import forms
from django.db import models

class ContactForm(forms.Form):
    domain = forms.CharField(widget=forms.HiddenInput())#widget=forms.HiddenInput()
    city = forms.CharField(widget=forms.HiddenInput())
    key = forms.CharField(widget=forms.HiddenInput())

class UserInfo(models.Model):
    name = models.CharField(max_length=20)#widget=forms.HiddenInput()
    email = models.CharField(max_length=30)
    subject = models.CharField(max_length=30)
    massage = models.CharField(max_length=250)
    def __str__(self):
        return self.subject

class UserMessage(models.Model):
    name = models.CharField(max_length=20)#widget=forms.HiddenInput()
    email = models.CharField(max_length=30)
    subject = models.CharField(max_length=30)
    massage = models.CharField(max_length=250)
    def __str__(self):
        return self.name



  


